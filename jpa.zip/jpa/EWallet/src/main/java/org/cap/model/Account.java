package org.cap.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Account {
	@Id
	private long accountNo;
	private double openingBalance;
	
	@Enumerated(EnumType.STRING)
	private AccountType accountType;
	private LocalDateTime openingDate;
	private String description;
	
	@ManyToOne
	@JoinColumn(name = "customerId")
	private Customer customer;
	
	@OneToMany(targetEntity = Transactions.class,mappedBy ="fromAccount")
	private List<Transactions> fromActransactions=new ArrayList<Transactions>();
	
	@OneToMany(targetEntity = Transactions.class,mappedBy ="toAccount")
	private List<Transactions> toActransactions=new ArrayList<Transactions>();

	public Account(long accountNo, double openingBalance, AccountType accountType, LocalDateTime openingDate,
			String description, Customer customer) {
		super();
		this.accountNo = accountNo;
		this.openingBalance = openingBalance;
		this.accountType = accountType;
		this.openingDate = openingDate;
		this.description = description;
		this.customer = customer;
	}

	public Account() {
		super();
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	public double getOpeningBalance() {
		return openingBalance;
	}

	public void setOpeningBalance(double openingBalance) {
		this.openingBalance = openingBalance;
	}

	public AccountType getAccountType() {
		return accountType;
	}

	public void setAccountType(AccountType accountType) {
		this.accountType = accountType;
	}

	public LocalDateTime getOpeningDate() {
		return openingDate;
	}

	public void setOpeningDate(LocalDateTime openingDate) {
		this.openingDate = openingDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public List<Transactions> getFromActransactions() {
		return fromActransactions;
	}

	public void setFromActransactions(List<Transactions> fromActransactions) {
		this.fromActransactions = fromActransactions;
	}

	public List<Transactions> getToActransactions() {
		return toActransactions;
	}

	public void setToActransactions(List<Transactions> toActransactions) {
		this.toActransactions = toActransactions;
	}

	public Account(long accountNo, double openingBalance, AccountType accountType, LocalDateTime openingDate,
			String description, Customer customer, List<Transactions> fromActransactions) {
		super();
		this.accountNo = accountNo;
		this.openingBalance = openingBalance;
		this.accountType = accountType;
		this.openingDate = openingDate;
		this.description = description;
		this.customer = customer;
		this.fromActransactions = fromActransactions;
	}
	
	
	

	

}
