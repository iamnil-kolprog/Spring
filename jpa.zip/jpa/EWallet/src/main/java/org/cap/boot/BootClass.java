package org.cap.boot;

import java.time.LocalDate;
import java.time.LocalDateTime;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.Account;
import org.cap.model.AccountType;
import org.cap.model.Address;
import org.cap.model.Customer;
import org.cap.model.TransactionType;
import org.cap.model.Transactions;


public class BootClass {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=
				Persistence.createEntityManagerFactory("bankplp");
		EntityManager entityManager=
				entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=
				entityManager.getTransaction();
		entityTransaction.begin();
		
		Address address=new Address("12-A", "South Car Street", "Chennai", "60041", "Tamil Nadu");
		Customer customer=new Customer("Tom", "Jerry", "23243243", "tom@gmail.com", LocalDate.of(1990, 3, 12), address);
		
		Address address2=new Address("22-Bv", "North an  Street", "Kolkata", "700078", "West Bengal");
		Customer customer2=new Customer("Dip", "Saha", "7856455", "dip@gmail.com", LocalDate.of(1997, 6, 15), address2);
		
		Account savings=new Account(98569058, 3000.0, AccountType.SAVINGS, LocalDateTime.of(2019, 1, 23,9,12,23), "Savings Account for self purpose", customer);
		Account current=new Account(65765767, 50000.0, AccountType.CURRENT, LocalDateTime.of(2017, 11, 2,9,12,23), "Business Purpose", customer);
		
		Account fixed2 = new Account(12345678, 5000.0, AccountType.FIXED_DEPOSIT, LocalDateTime.of(2019, 12, 23,9,12,23), "fixed money for 2 years", customer2);
		Account sav2 = new Account(25251425, 2000.0, AccountType.SAVINGS, LocalDateTime.of(2019, 8, 25, 8, 45), "savings for self", customer2);
		
		//Transactions trans=new Transactions(LocalDate.of(2018, 8, 15), TransactionType.DEBIT, 10000, description, fromAccount", toAccount);
		Transactions trans1 = new Transactions(LocalDate.of(2018, 8, 15), TransactionType.DEBIT, 500, "debited money from  ", savings);
		Transactions trans2 = new Transactions(LocalDate.of(2019, 8, 25), TransactionType.CREDIT, 500, "credited money to  ", savings);
		
		Transactions trans3 =new Transactions(LocalDate.of(2019, 10, 28), TransactionType.CREDIT, 800, "transfer 1 account to another account",fixed2 ,current);
		
		
		entityManager.persist(customer);
		entityManager.persist(savings);
		entityManager.persist(current);
		entityManager.persist(customer2);
		entityManager.persist(fixed2);
		entityManager.persist(sav2);
		
		
		entityManager.persist(trans1);
		entityManager.persist(trans2);
		
		entityManager.persist(trans3);
		  
		  
		entityTransaction.commit();
		entityManager.close();
		entityManagerFactory.close();

	}

}
