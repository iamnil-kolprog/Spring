package org.cap.model;

public enum AccountType {
	SAVINGS, CURRENT, HOME_LOAN, CAR_LOAN, EDUCATION_LOAN,RECURING_DEPOSIT,FIXED_DEPOSIT;

}
