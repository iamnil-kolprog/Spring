package org.cap.mapping.model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class TestClass {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=
				Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=
				entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=
				entityManager.getTransaction();
		entityTransaction.begin();
		
		
		/*
		 * Address address=new Address(123, "North Avvenue", "Hyderabad"); Customer
		 * customer=new Customer(1009, "Tom", address); address.setCustomer(customer);
		 * 
		 * entityManager.persist(customer); entityManager.persist(address);
		 */
		
		
		
		Company capg=new Company(1001, "Capgemini India Pvt Ltd");
		Company tcs=new Company(1234, "TATA Consultancy Services");
		
		
		Employee employee=new Employee("Tom", "Jerry", 34000, capg);
		Employee employee1=new Employee("Jack", "Thomson", 34120, capg);
		Employee employee2=new Employee("Tim", "Lee", 354600, tcs);
		Employee employee3=new Employee("Annie", "George", 90000, tcs);
		Employee employee4=new Employee("Annie", "George", 90000, capg);
		
		
		entityManager.persist(tcs);
		entityManager.persist(capg);
		
		entityManager.persist(employee4);
		entityManager.persist(employee3);
		entityManager.persist(employee2);
		entityManager.persist(employee1);
		entityManager.persist(employee);
		
		
		
		entityTransaction.commit();
		entityManager.close();
		entityManagerFactory.close();

	}

}
