package org.cap.boot;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import org.cap.model.Course;
import org.cap.model.CourseId;
import org.cap.model.Module;
import org.cap.model.Project;
import org.cap.model.Task;

public class BootClass {

	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory=
				Persistence.createEntityManagerFactory("jpademo");
		EntityManager entityManager=
				entityManagerFactory.createEntityManager();
		EntityTransaction entityTransaction=
				entityManager.getTransaction();
		entityTransaction.begin();
		
		/*
		 * Project project=new Project(1001, "SCB Core Banking");
		 * 
		 * Module module=new Module(); module.setProjectId(1234);
		 * module.setProjectName("ANZ Net Banking");
		 * module.setModuleName("NetBanking Login Module");
		 * 
		 * Task task=new Task(); task.setProjectId(1900);
		 * task.setProjectName("CNA Mobile Banking");
		 * task.setModuleName("Home Loan Module");
		 * task.setTaskName("Home Loan Interest Rate Task");
		 * 
		 * entityManager.persist(project); entityManager.persist(module);
		 * entityManager.persist(task);
		 */
		
		/*
		 * Course course=new Course(12, 13, "Java"); Course course2=new
		 * Course(12,33,"Oracle");
		 */
		
		Course course=new Course(new CourseId(12, 33), "MySql");
		Course course2=new Course(new CourseId(122, 33), "PostGres");
		
		entityManager.persist(course);
		entityManager.persist(course2);
		
		
		
		
		
		entityTransaction.commit();
		
		entityManager.close();
		entityManagerFactory.close();

	}

}
