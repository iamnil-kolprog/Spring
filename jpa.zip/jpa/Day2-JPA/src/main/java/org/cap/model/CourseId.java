package org.cap.model;

import java.io.Serializable;

import javax.persistence.Embeddable;
import javax.persistence.Id;

@Embeddable
public class CourseId implements Serializable{
	
	private int courseId;
	private int studId;
	public int getCourseId() {
		return courseId;
	}
	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}
	public int getStudId() {
		return studId;
	}
	public void setStudId(int studId) {
		this.studId = studId;
	}
	public CourseId(int courseId, int studId) {
		super();
		this.courseId = courseId;
		this.studId = studId;
	}
	public CourseId() {
		super();
	}
	@Override
	public String toString() {
		return "CourseId [courseId=" + courseId + ", studId=" + studId + "]";
	}
	
	
	
}
