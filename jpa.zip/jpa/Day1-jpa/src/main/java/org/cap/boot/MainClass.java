package org.cap.boot;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import org.cap.model.Employee;

public class MainClass {

	public static void main(String[] args) {
	
		EntityManagerFactory factory=
				Persistence.createEntityManagerFactory("jpademo");
		
		EntityManager manager=
				factory.createEntityManager();
		
		
		/*
		 * Employee employee=new Employee( "Tom", "Jerry", 23000,"tom1@gmail.com",
		 * LocalDate.of(2019, 12, 11),LocalTime.of(9, 23, 45),
		 * LocalDateTime.of(LocalDate.of(1991,1,23), LocalTime.of(11, 23, 23)),
		 * "tom324"); Employee employee1=new Employee( "Jack", "Thomson", 34000);
		 * Employee annie=new Employee(); //annie.setEmployeeId(190);
		 * annie.setSalary(45000); annie.setFirstName("Annie");
		 * annie.setEmailId("annie1@yahoo.co.in");
		 * annie.setDateOfJoining(LocalDate.now()); annie.setEntryTime(LocalTime.now());
		 * annie.setEmpPassword("annie123");
		 */
		EntityTransaction transaction=
				manager.getTransaction();
		transaction.begin();
			
		/*
		 * //trigger insert query manager.persist(employee); manager.persist(employee1);
		 * manager.persist(annie);
		 */
		
		
		
		//Employee employee=manager.find(Employee.class, 9);
		
		//manager.remove(employee);
		
		//employee.setSalary(55000);
		
		//System.out.println(employee);
		
		
		
		
		
		//JPQL query
		//Query query=manager.createQuery("from Employee e where e.emailId=:empEmailId");
		Query query=manager.createQuery("from Employee e where e.salary>=:empSalary");
		
		//query.setParameter("empEmailId", "tom@gmail.com");
		query.setParameter("empSalary", 23000.0);
		List<Employee> employees= query.getResultList();
		
		for(Employee emp:employees)
			System.out.println(emp);
		
		
		
		
		transaction.commit();
		
		manager.close();
		factory.close();
		
	}

}
