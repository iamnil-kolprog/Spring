package org.cap.model;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="Employee_Details")
public class Employee {
	@Id
	@GeneratedValue
	private int employeeId;
	@Column(name="fname",nullable = false)
	private String firstName;
	@Basic
	private String lastName;
	private double salary;
	@Column(unique = true,length = 100)
	private String emailId;
	
	
	private LocalDate dateOfJoining;
	private LocalTime entryTime;
	private LocalDateTime dateOfbirth;
	
	@Transient
	private String empPassword;
	
	
	
	
	public Employee( String firstName, String lastName, double salary, String emailId,
			LocalDate dateOfJoining, LocalTime entryTime, LocalDateTime dateOfbirth, String empPassword) {
		super();
		//this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.emailId = emailId;
		this.dateOfJoining = dateOfJoining;
		this.entryTime = entryTime;
		this.dateOfbirth = dateOfbirth;
		this.empPassword = empPassword;
	}

	public String getEmpPassword() {
		return empPassword;
	}

	public void setEmpPassword(String empPassword) {
		this.empPassword = empPassword;
	}

	public Employee( String firstName, String lastName, double salary, String emailId,
			LocalDate dateOfJoining, LocalTime entryTime, LocalDateTime dateOfbirth) {
		super();
		//this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.emailId = emailId;
		this.dateOfJoining = dateOfJoining;
		this.entryTime = entryTime;
		this.dateOfbirth = dateOfbirth;
	}
	
	public Employee(int employeeId, String firstName, String lastName, double salary, String emailId,
			LocalDate dateOfJoining, LocalTime entryTime, LocalDateTime dateOfbirth) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.emailId = emailId;
		this.dateOfJoining = dateOfJoining;
		this.entryTime = entryTime;
		this.dateOfbirth = dateOfbirth;
	}
	public LocalDate getDateOfJoining() {
		return dateOfJoining;
	}
	public void setDateOfJoining(LocalDate dateOfJoining) {
		this.dateOfJoining = dateOfJoining;
	}
	public LocalTime getEntryTime() {
		return entryTime;
	}
	public void setEntryTime(LocalTime entryTime) {
		this.entryTime = entryTime;
	}
	public LocalDateTime getDateOfbirth() {
		return dateOfbirth;
	}
	public void setDateOfbirth(LocalDateTime dateOfbirth) {
		this.dateOfbirth = dateOfbirth;
	}
	public Employee( String firstName, String lastName, double salary, String emailId) {
		super();
		//this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.emailId = emailId;
	}
	public Employee(int employeeId, String firstName, String lastName, double salary, String emailId) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
		this.emailId = emailId;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public Employee() {
		super();
	}
	public Employee( String firstName, String lastName, double salary) {
		super();
		//this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
	}
	
	public Employee(int employeeId, String firstName, String lastName, double salary) {
		super();
		this.employeeId = employeeId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.salary = salary;
	}
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", salary=" + salary + ", emailId=" + emailId + ", dateOfJoining=" + dateOfJoining + ", entryTime="
				+ entryTime + ", dateOfbirth=" + dateOfbirth + ", empPassword=" + empPassword + "]";
	}
	
	

}
