package com.cap.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Transaction {
@Id
	private int transactionId;
	private String transactionType;
	private long transactionAmount;
	@ManyToOne
	@JoinColumn(name="AccountNumber")
	private Account account;
	public Transaction(int transactionId, String transactionType, long transactionAmount, Account account) {
		super();
		this.transactionId = transactionId;
		this.transactionType = transactionType;
		this.transactionAmount = transactionAmount;
		this.account = account;
	}
	public Transaction() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", transactionType=" + transactionType
				+ ", transactionAmount=" + transactionAmount + ", account=" + account + "]";
	}
	
}
