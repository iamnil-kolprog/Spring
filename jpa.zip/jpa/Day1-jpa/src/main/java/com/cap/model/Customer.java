package com.cap.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;


@Entity
public class Customer {
	
	@Id
	private long customerId;
	
	@Column(name="Name",nullable=false,length=60)
	private String customerName;

	@Column(name="Email",nullable=false,length=100)
	private String email;

	@Column(name="MobileNo",nullable=false)
	private long customerMobNo;
	
	@OneToOne
	@JoinColumn(name="addressId")
	private Address address;
	@OneToMany(targetEntity=Account.class,fetch=FetchType.LAZY,mappedBy="customer")
	private List<Account> list=new ArrayList<Account>();

	public long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getCustomerMobNo() {
		return customerMobNo;
	}

	public void setCustomerMobNo(long customerMobNo) {
		this.customerMobNo = customerMobNo;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
	

	public Customer(long customerId, String customerName, String email, long customerMobNo, Address address) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.email = email;
		this.customerMobNo = customerMobNo;
		this.address = address;
	}

	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", email=" + email
				+ ", customerMobNo=" + customerMobNo + ", address=" + address + "]";
	}

	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}
