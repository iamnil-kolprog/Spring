package com.cap.model;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Address {
	@Id
	private int addressId;
	private String addressLine;
	
	public int getAddressId() {
		return addressId;
	}
	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}
	public String getAddressLine() {
		return addressLine;
	}
	public void setAddressLine(String addressLine) {
		this.addressLine = addressLine;
	}
	public Address(int addressId, String addressLine) {
		super();
		this.addressId = addressId;
		this.addressLine = addressLine;
	}
	public Address() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	

}
