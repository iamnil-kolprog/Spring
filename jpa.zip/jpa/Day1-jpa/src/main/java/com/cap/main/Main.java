package com.cap.main;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.cap.model.Account;
import com.cap.model.Address;
import com.cap.model.Customer;
import com.cap.model.Transaction;



public class Main {

	public static void main(String[] args) {
			// TODO Auto-generated method stub
			EntityManagerFactory factory=Persistence.createEntityManagerFactory("jpademo");
			EntityManager manager=factory.createEntityManager();		
		
			EntityTransaction transaction=manager.getTransaction();
			transaction.begin();
			Address address=new Address(121,"Avenue Road");
			Customer customer=new Customer(123l,"Shashank","s@gmail.com",87223333803l,address);
			Account account=new Account(8888l,"Savings",80000l,customer);
			Transaction tran=new Transaction(111,"Debit",1000l,account);
		
			
			manager.persist(address);
			manager.persist(customer);
			manager.persist(account);
			manager.persist(tran);
			

			transaction.commit();
			manager.close();
			factory.close();
			
			
			

		}

	}


