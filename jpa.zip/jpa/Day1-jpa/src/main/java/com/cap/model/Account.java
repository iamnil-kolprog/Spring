package com.cap.model;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

@Entity
public class Account {
	@Id
	private long accountNo;
	private String accountType;
	private long accountBalance;
	@ManyToOne
	@JoinColumn(name="customerId")
	private Customer customer;
	@OneToMany(targetEntity=Transaction.class,fetch=FetchType.LAZY,mappedBy="account")
	private List<Transaction> list=new ArrayList<Transaction>();

	
	public Account(long accountNo, String accountType, long accountBalance, Customer customer) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.accountBalance = accountBalance;
		this.customer = customer;
	}
	
	
	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountType=" + accountType + ", accountBalance=" + accountBalance
				+ ", customer=" + customer + "]";
	}
	


	public Account() {
		super();
		// TODO Auto-generated constructor stub
	}


	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public long getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(long accountBalance) {
		this.accountBalance = accountBalance;
	}
	public Customer getCustomer() {
		return customer;
	}
	public void setCustomer(Customer customer) {
		this.customer = customer;
	} 
	
	
}
