package com.stock.exception;

//Exception class for this Application

public class StockException extends Exception {
	public StockException() {
		super();
	}

	public StockException(String message) {
		super(message);
	}

}
