package com.capg.Review.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Reviews {
	@Id
	private int review_id;
	private String description;
	@OneToOne
	private Reviewer reviewer_id;
	
	
	public Reviews() {
		super();
	}
	public int getReview_id() {
		return review_id;
	}
	public void setReview_id(int review_id) {
		this.review_id = review_id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public Reviewer getReviewer_id() {
		return reviewer_id;
	}
	public void setReviewer_id(Reviewer reviewer_id) {
		this.reviewer_id = reviewer_id;
	}
	public Reviews(int review_id, String description, Reviewer reviewer_id) {
		super();
		this.review_id = review_id;
		this.description = description;
		this.reviewer_id = reviewer_id;
	}
	
	
}
