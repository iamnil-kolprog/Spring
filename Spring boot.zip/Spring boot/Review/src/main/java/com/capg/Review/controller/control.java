package com.capg.Review.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.Review.model.Reviewer;
import com.capg.Review.model.Reviews;
import com.capg.Review.service.Service;



@RestController
public class control {
	@Autowired
	private Service service;
	
	@RequestMapping("/rev")
	public List<Reviews> getA() {
		return service.getAll();
	}
	
	@RequestMapping("/rev/{id}")
	public Optional<Reviews> getId(@PathVariable int id)
	{
		return service.getById(id);
	}
	
	@PostMapping("/rev")
	public void add(@RequestBody Reviews s1) {
		service.addStud(s1);
	}
	
	@DeleteMapping("/rev/{id}")
	public void del(@PathVariable int id) {
		service.delete(id);
	}
	
	@PutMapping("/rev/{id}")
	public void update(@PathVariable int id,@RequestBody Reviews s1) {
		service.updateS(id, s1);
	}
	
	@PostMapping("/revi")
	public void addReviewer(Reviewer re) {
		service.addRev(re);
	}
	
	@RequestMapping("/revi")
	public List<Reviewer> getB() {
		return service.getAl();
	}
}
