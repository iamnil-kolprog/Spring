package com.capg.Review.crudRepository;

import org.springframework.data.repository.CrudRepository;

import com.capg.Review.model.Reviewer;

public interface Repositor extends CrudRepository<Reviewer, Integer> {

}
