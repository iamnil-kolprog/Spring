package com.capg.Review.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.capg.Review.crudRepository.Reposit;
import com.capg.Review.crudRepository.Repositor;
import com.capg.Review.model.Reviewer;
import com.capg.Review.model.Reviews;





@org.springframework.stereotype.Service
public class Service {
	
	@Autowired
	private Reposit repo;
	@Autowired
	private Repositor rep;
	
	public List<Reviews> getAll() {
		return (List<Reviews>) repo.findAll();
	}
	
	
	public Optional<Reviews> getById(int id) {
		return repo.findById(id);
		
	}
	
	public void addStud(Reviews rev) {
		repo.save(rev);
	}

	public void delete(int id) {
		
		repo.deleteById(id);
	}
	
	
	
	
	
	
	public void updateS(int id,Reviews rev) {
		repo.deleteById(id);
		rev.setReview_id(id);
		repo.save(rev);
		
	}
	
	
	
	
	public void addRev(Reviewer rev) {
		rep.save(rev);
	}

	public List<Reviewer> getAl() {
		return (List<Reviewer>) rep.findAll();
	}
}
