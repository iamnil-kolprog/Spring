package com.capg.Review.model;

import javax.persistence.Entity;
import javax.persistence.Id;
//import javax.persistence.Inheritance;
//import javax.persistence.InheritanceType;

@Entity
public class Reviewer {
	@Id
	private int reviewer_id;
	private String name;
	private String email;



	
	public int getReviewer_id() {
		return reviewer_id;
	}

	public void setReviewer_id(int reviewer_id) {
		this.reviewer_id = reviewer_id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	

	public Reviewer() {
		super();
	}

	public Reviewer(int reviewer_id, String name, String email) {
		super();
		this.reviewer_id = reviewer_id;
		this.name = name;
		this.email = email;
		
	}
	
	

}
