package com.capg.DupliReview;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DupliReviewApplication {

	public static void main(String[] args) {
		SpringApplication.run(DupliReviewApplication.class, args);
	}

}
