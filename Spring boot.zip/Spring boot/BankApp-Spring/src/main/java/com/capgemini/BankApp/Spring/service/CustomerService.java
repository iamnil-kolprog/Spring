package com.capgemini.BankApp.Spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.BankApp.Spring.beans.Address;
import com.capgemini.BankApp.Spring.beans.Customer;
import com.capgemini.BankApp.Spring.exception.IdNotFound;
import com.capgemini.BankApp.Spring.repository.CustomerRepo;
@Service
public class CustomerService {
	
	@Autowired
	private CustomerRepo customerRepo;
	
	@Autowired
	private AddressService addressService;

	public List<Customer> getAllCustomers() {
		// TODO Auto-generated method stub
		return customerRepo.findAll();
		
	}

	public Customer getCustomer(int customerId) {
		// TODO Auto-generated method stub
		if(!customerRepo.findById(customerId).isPresent()) {
			throw new IdNotFound("Customer Id "+customerId+" is not present");
		}
		else {
		List<Customer> customers= getAllCustomers();
		for(Customer c : customers) {
			if(c.getCustomerId()==customerId) {
				return c;
			}
		}

		return null;
		}
	}

	public void addCustomer(Customer customer, int addressId) {
		// TODO Auto-generated method stub
		Address address = addressService.getAddress(addressId);
		customer.setAddress(address);
		customerRepo.save(customer);
		
	}

	public void updateCustomer(Customer customer, int customerId) {
		// TODO Auto-generated method stub
		if(!customerRepo.findById(customerId).isPresent()) {
			throw new IdNotFound("Customer Id "+customerId+" is not present");
		}
		else {
		Customer cust = getCustomer(customerId);
		int addressId = cust.getAddress().getAddressId();
		Address address=addressService.getAddress(addressId);
		customer.setAddress(address);
		customer.setCustomerId(customerId);
		customerRepo.save(customer);
		}
		
	}

	public void deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		if(!customerRepo.findById(customerId).isPresent()) {
			throw new IdNotFound("Customer Id "+customerId+" is not present");
		}
		else {
		customerRepo.deleteById(customerId);
		}
		
	}

}
