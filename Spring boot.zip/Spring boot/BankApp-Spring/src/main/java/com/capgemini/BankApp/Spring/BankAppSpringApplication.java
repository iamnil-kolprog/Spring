package com.capgemini.BankApp.Spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankAppSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(BankAppSpringApplication.class, args);
	}

}
