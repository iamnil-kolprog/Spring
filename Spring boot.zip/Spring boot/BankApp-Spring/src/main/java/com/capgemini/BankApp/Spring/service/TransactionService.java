package com.capgemini.BankApp.Spring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.BankApp.Spring.beans.Account;
import com.capgemini.BankApp.Spring.beans.Transaction;
import com.capgemini.BankApp.Spring.repository.AccountRepo;
import com.capgemini.BankApp.Spring.repository.TransactionRepo;

@Service
public class TransactionService {
	
	@Autowired
	private TransactionRepo transrepo;
	
	@Autowired
	private AccountService accountService;
	
	@Autowired
	private AccountRepo accountRepo;

	public List<Transaction> getAllTransactions() {
		// TODO Auto-generated method stub
		return transrepo.findAll();
	}

	public void addTransaction(Transaction transaction) {
		// TODO Auto-generated method stub
		Account account,account1;
		if(transaction.getTransactionType().equalsIgnoreCase("credit")) {
			 account=depositTransact(transaction.getTransactionAmount(), transaction.getFormAccount());
			 transaction.setToAccount(0);
			 accountRepo.save(account);
			 transaction.setAccount(account);
			 transrepo.save(transaction);
		}else if(transaction.getTransactionType().equalsIgnoreCase("debit")) {
			account=withDrawTransact(transaction.getTransactionAmount(), transaction.getFormAccount());
			 transaction.setToAccount(0);
			 accountRepo.save(account);
			 transaction.setAccount(account);
			 transaction.setAccount(account);
			 transrepo.save(transaction);
		}
		else if(transaction.getTransactionType().equalsIgnoreCase("fund transfer")) {
			account=withDrawTransact(transaction.getTransactionAmount(), transaction.getToAccount());
			account1=depositTransact(transaction.getTransactionAmount(), transaction.getFormAccount());
			transaction.setAccount(account);
			transaction.setAccount(account1);
			transrepo.save(transaction);
		}
		
	}
	private Account depositTransact(long amount,int accNO) {
		
		Account account = accountService.getAccount(accNO);
		account.setAccountOpeningBalance((account.getAccountOpeningBalance()+amount));
		return account;
	
}
	private Account withDrawTransact(long amount,int accNO) {
	
	Account account = accountService.getAccount(accNO);
	account.setAccountOpeningBalance(account.getAccountOpeningBalance()-amount);
	return account;

}


}
