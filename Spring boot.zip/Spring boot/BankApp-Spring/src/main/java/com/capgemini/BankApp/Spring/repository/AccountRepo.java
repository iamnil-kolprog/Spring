package com.capgemini.BankApp.Spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.BankApp.Spring.beans.Account;

public interface AccountRepo extends JpaRepository<Account, Integer>{

}
