package com.capgemini.BankApp.Spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.BankApp.Spring.beans.Account;
import com.capgemini.BankApp.Spring.service.AccountService;


@RestController
public class AccountControl {
	
	@Autowired
	private AccountService accountService;
	
	@GetMapping("/account")
	public List<Account> getAllAccounts(){
		return accountService.getAllAccounts();	
	}
	@PostMapping("/account/{cid}")
	public void addAccount(@RequestBody Account account,@PathVariable int cid) {
		accountService.addAccount(account,cid);
	}
	@GetMapping("/account/{acc_No}")
	public Account getAccount(@PathVariable int acc_No) {
		return accountService.getAccount(acc_No);
	}
	
	@PutMapping("/account/{acc_No}")
	public void updateAccount(@RequestBody Account account,@PathVariable int acc_No) {
		accountService.updateAccount(acc_No,account);
	}
	
	@DeleteMapping("account/{acc_No}")
	public void delete(@PathVariable int acc_No) {
		accountService.deleteAccount(acc_No);
	}

}
