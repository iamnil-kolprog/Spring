package com.capgemini.BankApp.Spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.BankApp.Spring.beans.Transaction;
import com.capgemini.BankApp.Spring.repository.TransactionRepo;
import com.capgemini.BankApp.Spring.service.TransactionService;



@RestController
public class TransactionControl {
	
	@Autowired
	private TransactionService transactionService;
	
	
	@GetMapping("/trans")
	public List<Transaction> getAllTransactions(){
		return  transactionService.getAllTransactions();
	}
	@PostMapping("/trans")
	public void addTransaction(@RequestBody Transaction transaction) {
		transactionService.addTransaction(transaction);
	}

}
