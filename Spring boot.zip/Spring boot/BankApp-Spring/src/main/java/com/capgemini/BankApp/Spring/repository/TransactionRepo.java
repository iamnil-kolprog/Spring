package com.capgemini.BankApp.Spring.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.BankApp.Spring.beans.Transaction;

public interface TransactionRepo extends JpaRepository<Transaction, Integer>{

}
