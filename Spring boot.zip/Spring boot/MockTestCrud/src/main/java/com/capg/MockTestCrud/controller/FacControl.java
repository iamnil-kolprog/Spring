package com.capg.MockTestCrud.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.MockTestCrud.beans.Faculty;
import com.capg.MockTestCrud.service.FacService;

@RestController
public class FacControl {
	@Autowired
	private FacService facs;
	
	@GetMapping("/fac")
	public List<Faculty> gatAll(){
		return facs.getA();
	}
	
	@PostMapping("/fac")
	public void addF(@RequestBody Faculty fac) {
		facs.addF(fac);
	}
}
