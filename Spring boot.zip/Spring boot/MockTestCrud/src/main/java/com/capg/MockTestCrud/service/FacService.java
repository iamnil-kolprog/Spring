package com.capg.MockTestCrud.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.MockTestCrud.Repository.FacultyRepo;
import com.capg.MockTestCrud.beans.Faculty;

@Service
public class FacService {
	@Autowired
	private FacultyRepo facr;

	public List<Faculty> getA() {
		// TODO Auto-generated method stub
		return (List<Faculty>) facr.findAll();
	}

	public void addF(Faculty fac) {
		// TODO Auto-generated method stub
		facr.save(fac);
	}

	public Faculty getF(int id) {
		List<Faculty> faculty= new ArrayList<>();
		faculty = (List<Faculty>) facr.findAll();
		for(Faculty f : faculty) {
			if(f.getFacId()==id) {
				return f;
			}
		}
		return null;
	}
	
	
}
