package com.capg.MockTestCrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockTestCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(MockTestCrudApplication.class, args);
	}

}
