package com.capg.MockTestCrud.Repository;

import org.springframework.data.repository.CrudRepository;

import com.capg.MockTestCrud.beans.SessionCrud;

public interface Reposit extends CrudRepository<SessionCrud, String> {

}
