package com.capg.MockTestCrud.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capg.MockTestCrud.beans.Faculty;
import com.capg.MockTestCrud.beans.SessionCrud;
import com.capg.MockTestCrud.service.FacService;
import com.capg.MockTestCrud.service.SesService;



@RestController
public class Control {

	@Autowired
	private SesService serv;
	
	@Autowired
	private FacService facs;
	
	@RequestMapping("/ses")
	public List<SessionCrud> getA() {
		return serv.getAll();
	}
	
	@RequestMapping("/ses/{id}")
	public Optional<SessionCrud> getId(@PathVariable String id)
	{
		return serv.getById(id);
	}
	
	@PostMapping("/ses/{fid}")
	public void add(@RequestBody SessionCrud s1,@PathVariable int fid) {
		Faculty fac = facs.getF(fid);
		s1.setFaculty(fac);
		serv.addSes(s1);
	}
	
	@DeleteMapping("/ses{id}")
	public void del(@PathVariable String id) {
		serv.delete(id);
	}
	
	@PutMapping("/ses/{id}")
	public void update(@PathVariable String id,@RequestBody SessionCrud s1) {
		serv.updateS(id, s1);
	}
}
