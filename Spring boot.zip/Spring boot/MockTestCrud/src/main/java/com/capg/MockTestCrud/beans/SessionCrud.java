package com.capg.MockTestCrud.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class SessionCrud {
	@Id
	private String sessionName;
	
	private int duration;
	
	private String role;
	@OneToOne
	private Faculty faculty;
	public String getSessionName() {
		return sessionName;
	}
	public void setSessionName(String sessionName) {
		this.sessionName = sessionName;
	}
	public int getDuration() {
		return duration;
	}
	
	public SessionCrud() {
		super();
	}
	
	
	public SessionCrud(String sessionName, int duration,  String role) {
		super();
		this.sessionName = sessionName;
		this.duration = duration;
		this.role = role;
	}
	
	
	public void setDuration(int duration) {
		this.duration = duration;
	}
	
	public Faculty getFaculty() {
		return faculty;
	}
	public void setFaculty(Faculty faculty) {
		this.faculty = faculty;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	
	
}
