package com.capg.MockTestCrud.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.MockTestCrud.Repository.FacultyRepo;
import com.capg.MockTestCrud.Repository.Reposit;
import com.capg.MockTestCrud.beans.Faculty;
import com.capg.MockTestCrud.beans.SessionCrud;



@Service
public class SesService {
	
//	@Autowired
//	private com.capg.MockTestCrud.Repository.Reposit repo;
	
	@Autowired
	private Reposit repo;
	
	
	
	
	public List<SessionCrud> getAll() {
		return (List<SessionCrud>) repo.findAll();
	}
	
	
	public Optional<SessionCrud> getById(String id) {
		return repo.findById(id);
		
	}
	
	public void addSes(SessionCrud ses) {
		repo.save(ses);
	}

	public void delete(String id) {
		
		repo.deleteById(id);
	}
	
	
	
	public void updateS(String id,SessionCrud ses) {
		//repo.deleteById(id);
		ses.setSessionName(id);
		repo.save(ses);
		
	}
	
	

}
