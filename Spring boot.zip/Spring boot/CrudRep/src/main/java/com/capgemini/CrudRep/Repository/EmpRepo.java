package com.capgemini.CrudRep.Repository;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.CrudRep.model.Employee;

public interface EmpRepo extends CrudRepository<Employee, Integer> {

}
