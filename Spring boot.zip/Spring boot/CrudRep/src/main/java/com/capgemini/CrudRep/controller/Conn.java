package com.capgemini.CrudRep.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.CrudRep.model.Employee;
import com.capgemini.CrudRep.service.Serv;
@RestController
public class Conn {
	
	@Autowired
	private Serv ser;
	
	
	
	@RequestMapping("/emp{id}")
	public Optional<Employee> getspec(@PathVariable int id){
		return ser.get(id);
	}
	@RequestMapping("/emp")
	public List<Employee> get() {
		return ser.getAll();
	}
	@RequestMapping(method=RequestMethod.POST,value="/emp")
	public void add(@RequestBody Employee emp)
	{
		ser.addEmp(emp);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/emp{id}")
	public void delete(@PathVariable int id) {
		ser.delete(id);
	}
	
	
	
	
}	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*@RequestMapping(value="/addemp", method=RequestMethod.POST)
	public void Add(@RequestBody Employee e1) {
		 ser.addEmp(e1);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/delete{id}")
	public void remove(@PathVariable int id) {
		ser.delete(id);
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/update{id}")
	public void update(@PathVariable int id,@RequestBody Employee emp) {
		ser.updateEmp(id, emp);
	}*/


