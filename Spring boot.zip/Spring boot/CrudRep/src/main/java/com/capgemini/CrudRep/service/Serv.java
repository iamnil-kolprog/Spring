package com.capgemini.CrudRep.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.CrudRep.Repository.EmpRepo;
import com.capgemini.CrudRep.model.Employee;

@RestController
public class Serv {
	
	@Autowired
	private EmpRepo emprep;

	/*List<Employee> employee = new ArrayList<Employee>(Arrays.asList(new Employee(10, "dip", 50, "analyst "),
			 new Employee(20, "nil", 50, "testing"),
			 new Employee(30, "nilanjan", 40, "associate"),
			 new Employee(40, "nila", 4, "programmer")));
	*/
	@RequestMapping
	public List<Employee> getAll(){
		return (List<Employee>) emprep.findAll();
		
	}
	
	public Optional<Employee> get(int id) {
		return emprep.findById(id);
	}
	
	public void addEmp(Employee e) {
		emprep.save(e);
	}
	
	public void delete(int id) {
		emprep.deleteById(id);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	 
	 
	/* public List<Employee> getAll() {
		 return employee;
	 }
	 
	 public List<Employee> getSpecific(int id){
		 List<Employee> dupli = new ArrayList<>();
		 
		for(Employee e: employee) {
			if(e.getId()==id) {
				dupli.add(e);
			}
			
		}
		if(dupli.isEmpty()) {
			return null;
		}else
		{
			return dupli;
		}
		 
	 }
	 
	 
	 public void addEmp(Employee emp) {
		  employee.add(emp);
	 }
	 
	 
	 public void delete(int id) {
		 for(Employee e : employee) {
			 if(e.getId()==id) {
				 employee.remove(e);
			 }
		 }
	 }
	 
	 public void updateEmp(int id,Employee emp) {
		 
		for(int i=0;i<employee.size();i++) {
			Employee e = employee.get(i);
			
			if(e.getId()==id) {
				employee.set(id, emp);
				return;
			}
		}
	 }*/
}
