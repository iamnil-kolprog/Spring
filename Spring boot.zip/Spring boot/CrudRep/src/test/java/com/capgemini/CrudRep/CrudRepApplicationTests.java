package com.capgemini.CrudRep;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudRepApplicationTests {

	@Test
	void contextLoads() {
	}

}
