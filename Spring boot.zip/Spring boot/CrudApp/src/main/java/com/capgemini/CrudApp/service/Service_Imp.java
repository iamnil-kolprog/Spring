package com.capgemini.CrudApp.service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.stereotype.Service;

import com.capgemini.CrudApp.beans.Employee;

@Service
public class Service_Imp {
	
	 List<Employee> employee = new ArrayList<Employee>(Arrays.asList(new Employee(10, "dip", 50000, "analyst "),
			 new Employee(20, "nil", 5000, "testing"),
			 new Employee(30, "nilanjan", 40000, "associate"),
			 new Employee(40, "nila", 40000, "programmer")));
	 
	 
	 public List<Employee> getAll() {
		 return employee;
	 }
	 
	 public List<Employee> getSpecific(int id){
		 List<Employee> dupli = new ArrayList<>();
		 
		for(Employee e: employee) {
			if(e.getId()==id) {
				dupli.add(e);
			}
			
		}
		if(dupli.isEmpty()) {
			return null;
		}else
		{
			return dupli;
		}
		 
	 }
	 
	 
	 public void addEmp(Employee emp) {
		  employee.add(emp);
	 }
	 
	 
	 public void delete(int id) {
		 for(Employee e : employee) {
			 if(e.getId()==id) {
				 employee.remove(e);
			 }
		 }
	 }
	 
	 public void updateEmp(int id,Employee emp) {
		 
		for(int i=0;i<employee.size();i++) {
			Employee e = employee.get(i);
			
			if(e.getId()==id) {
				employee.set(id, emp);
				return;
			}
		}
	 }
	

}
