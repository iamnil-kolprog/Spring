package com.capgemini.CrudApp.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.CrudApp.beans.Employee;
import com.capgemini.CrudApp.service.Service_Imp;

@RestController
public class Demo {
	@Autowired
	private Service_Imp ser;
	
	@RequestMapping("/allemp")
	public List<Employee> get() {
		return ser.getAll();
	}
	
	@RequestMapping("/specemp{id}")
	public List<Employee> getspec(@PathVariable int id){
		return ser.getSpecific(id);
	}
	
	@RequestMapping(value="/addemp", method=RequestMethod.POST)
	public void Add(@RequestBody Employee e1) {
		 ser.addEmp(e1);
	}
	
	@RequestMapping(method=RequestMethod.DELETE,value="/delete{id}")
	public void remove(@PathVariable int id) {
		ser.delete(id);
	}
	
	@RequestMapping(method=RequestMethod.PUT,value="/update{id}")
	public void update(@PathVariable int id,@RequestBody Employee emp) {
		ser.updateEmp(id, emp);
	}
}
