package com.capgemini.firstapp.cntroller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.firstapp.beans.Employee;

@RestController
public class Demo {
	
	@RequestMapping("/hello")
	public String helloWorld() {
		return "heloo world from spring boot";
	}
	
	/*Employee e = new Employee(10, "dip", 50000, "analyst ");
	Employee e1 = new Employee(20, "nil", 5000, "testing");
	Employee e2 = new Employee(30, "nilanjna", 40000, "associate");*/
	
	
	@RequestMapping("/employee")
	public List<Employee> data() {
		List<Employee> employee =new ArrayList<>();
		Employee e = new Employee(10, "dip", 50000, "analyst ");
		Employee e1 = new Employee(20, "nil", 5000, "testing");
		Employee e2 = new Employee(30, "nilanjan", 40000, "associate");
		employee.add(e);
		employee.add(e1);
		employee.add(e2);
		return (List<Employee>) employee;
	}
}
