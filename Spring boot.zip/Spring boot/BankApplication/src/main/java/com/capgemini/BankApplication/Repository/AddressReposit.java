package com.capgemini.BankApplication.Repository;

import org.springframework.data.repository.CrudRepository;

import com.capgemini.BankApplication.beans.Address;

public interface AddressReposit extends CrudRepository<Address, Integer>{

}
