package com.capg.CandyMan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CandyManApplication {

	public static void main(String[] args) {
		SpringApplication.run(CandyManApplication.class, args);
	}

}
