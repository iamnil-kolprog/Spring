package com.capg.CandyMan.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.CandyMan.Reposit.EmpRepo;
import com.capg.CandyMan.beans.Address;
import com.capg.CandyMan.beans.Employee;

@Service
public class EmpService {
	
	@Autowired
	private EmpRepo empr;
	
	@Autowired
	private AddService ads;

	public List<Employee> getE() {
		// TODO Auto-generated method stub
		return (List<Employee>) empr.findAll();
	}

	public void addE(Employee e, int aid) {
		// TODO Auto-generated method stub
		Address add = ads.getAdd(aid);
		e.setAddress(add);
		empr.save(e);
		
	}
	
	
}
