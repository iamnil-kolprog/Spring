package com.capg.CandyMan.exception;

public class IDNotFound extends RuntimeException{

	public IDNotFound(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
