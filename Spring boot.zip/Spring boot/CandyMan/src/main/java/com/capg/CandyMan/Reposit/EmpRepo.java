package com.capg.CandyMan.Reposit;

import org.springframework.data.repository.CrudRepository;

import com.capg.CandyMan.beans.Employee;

public interface EmpRepo extends CrudRepository<Employee, Integer> {

}
