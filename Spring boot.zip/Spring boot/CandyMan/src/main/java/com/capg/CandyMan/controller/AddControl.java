package com.capg.CandyMan.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.CandyMan.Service.AddService;
import com.capg.CandyMan.beans.Address;

@RestController
public class AddControl {
	
	@Autowired
	private AddService ads;
	@GetMapping("/add")
	public List<Address> getAll(){
		return ads.getADd();
	}
	@PostMapping("/add")
	public void addA(@RequestBody Address a) {
		ads.addA(a);
	}
	
	@GetMapping("/add/{id}")
	public Optional<Address> getAA(@PathVariable int id) {
		return ads.getAA(id);
	}
	

}
