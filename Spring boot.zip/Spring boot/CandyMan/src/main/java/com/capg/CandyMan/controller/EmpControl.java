package com.capg.CandyMan.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capg.CandyMan.Service.EmpService;
import com.capg.CandyMan.beans.Address;
import com.capg.CandyMan.beans.Employee;

@RestController
public class EmpControl {
	
	@Autowired
	private EmpService ems;
	
	@GetMapping("/emp")
	public List<Employee> getE(){
		return ems.getE();
	}
	
	@PostMapping("/emp/{aid}")
	public void addE(@RequestBody Employee e,@PathVariable int aid) {
		ems.addE(e,aid); 
	}

}
