package com.capg.CandyMan.Reposit;

import org.springframework.data.repository.CrudRepository;

import com.capg.CandyMan.beans.Address;

public interface AddRepo extends CrudRepository<Address, Integer> {

}
