package com.capg.CandyMan.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capg.CandyMan.Reposit.AddRepo;
import com.capg.CandyMan.beans.Address;
import com.capg.CandyMan.exception.IDNotFound;
@Service
public class AddService {
	
	@Autowired
	private AddRepo adr;

	public List<Address> getADd() {
		// TODO Auto-generated method stub
		return (List<Address>) adr.findAll();
	}
	
	

	public void addA(Address a) {
		// TODO Auto-generated method stub
		adr.save(a);
	}
	
	public Address getAdd(int aid) {
		List<Address> address=  (List<Address>) adr.findAll();
		for(Address a : address) {
			if(a.getAddId()==aid) {
				return a;
			}
		}
		return null;
	}



	public Optional<Address> getAA(int id) {
		// TODO Auto-generated method stub
		if(!adr.findById(id).isPresent()) {
			throw new IDNotFound("Id not present");
		}
		return adr.findById(id);
	}

}
