package com.capg.CandyMan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CandyManApplicationTests {

	@Test
	void contextLoads() {
	}

}
